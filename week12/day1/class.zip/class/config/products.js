const  products = [ {
    id:1,
    name: 'cat'
},{
    id:2,
    name: 'dog'
},{
    id:3,
    name: 'fish'
}
                    
                    ]

module.exports = products